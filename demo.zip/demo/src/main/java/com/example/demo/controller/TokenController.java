package com.example.demo.controller;

import com.example.demo.model.Token;
import com.example.demo.model.TokenRequestBody;
import com.example.demo.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class TokenController {

        @Autowired
        private TokenService tokenService;

        @PostMapping("/obtener-token")
        public ResponseEntity<Token> obtenerToken(@RequestBody TokenRequestBody requestBody) {
            Token token = tokenService.obtenerToken(requestBody);
            return ResponseEntity.ok(token);
        }


    @PostMapping("/obtener-token-list")
    public ResponseEntity<List<Token>> obtenerLibros() {
        List<Token> libros = tokenService.obtenerLibros();
        return ResponseEntity.ok(libros);
    }


    }

