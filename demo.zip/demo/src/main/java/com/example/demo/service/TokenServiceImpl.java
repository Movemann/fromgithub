package com.example.demo.service;


import com.example.demo.model.Token;
import com.example.demo.model.TokenRequestBody;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class TokenServiceImpl implements TokenService {

    @Value("${api.token.url}")
    private String apiUrl;

    @Value("${api.token.url.list}")
    private String apiUrlList;

    @Value("${api.token.url.path}")
    private String apiUrlPath;

    @Value("${api.token.url.list.path}")
    private String apiUrlListPath;


    @Override
    public Token obtenerToken(TokenRequestBody requestBody) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<TokenRequestBody> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Token> response = restTemplate.exchange(apiUrl+apiUrlPath, HttpMethod.GET, request, Token.class);
        return response.getBody();
    }



    @Override
    public List<Token> obtenerLibros() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        RestTemplate restTemplate = new RestTemplate();

        // Si es necesario, puedes agregar parámetros a la URL de la API, por ejemplo:
        // String apiUrl = "http://ejemplo.com/api/libros?parametro=valor";
        // ResponseEntity<List<Book>> response = restTemplate.exchange(apiUrl, HttpMethod.GET, new HttpEntity<>(headers), new ParameterizedTypeReference<List<Book>>() {});

        // Aquí se realiza la solicitud GET a la API para obtener la lista de libros
        ResponseEntity<List<Token>> response = restTemplate.exchange(apiUrlList+apiUrlListPath, HttpMethod.GET, new HttpEntity<>(headers), new ParameterizedTypeReference<List<Token>>() {});

        // Se devuelve la lista de libros obtenida en la respuesta
        return response.getBody();
    }
}
