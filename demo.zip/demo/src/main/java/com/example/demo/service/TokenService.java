package com.example.demo.service;

import com.example.demo.model.Token;
import com.example.demo.model.TokenRequestBody;

import java.util.List;

// TokenService.java
public interface TokenService {
    Token obtenerToken(TokenRequestBody requestBody);

    List<Token> obtenerLibros();
}
